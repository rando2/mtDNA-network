## zzz.R (2015-03-30)

##   Library Loading

## Copyright 2015 Emmanuel Paradis

## This file is part of the R-package `pegas'.
## See the file ../COPYING for licensing issues.

.PlotHaploNetEnv <- new.env()
.cacheVCF <- new.env()
